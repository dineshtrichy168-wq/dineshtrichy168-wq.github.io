Dinesh Kumar P — AIML Engineer Portfolio

Files:
- index.html — portfolio website
- DINESH_KUMAR_P_Resume.pdf — current resume

GitHub Pages:
1. Create/use repository: dineshtrichy168-wq.github.io
2. Upload index.html and DINESH_KUMAR_P_Resume.pdf to the repository root.
3. Settings → Pages → Source: Deploy from a branch → main → /(root).
4. Published site: https://dineshtrichy168-wq.github.io/
